# resi
DHL Auto Resi

How To USE
1. git clone https://github.com/AhanDotID/residhl-cookiemanual.git
2. cd resi
3. php resi2.php

