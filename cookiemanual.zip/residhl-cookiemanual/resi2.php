<?php
/**
 * CREATE : M34L@Ismail Muhammad Zeindy
 * GANTI TULISAN SEMOGA MATI MENDADAK LO AJG
 * Special Thanks To : Setya Mickala as SHARE AIRDROP
 */
awal:
echo "Berapa Banyak? ";
$count = trim(fgets(STDIN));

$i = 0;
$j = 0;


if (!empty($count)) {

    while(true){
        $randomAWB = rand(1000000000,9999999999);
        $check = dhl($randomAWB,$cookies);
        $json_check = json_decode($check,true);
        //print_r($json_check);

        foreach ($json_check as $key => $code){
            if ($key =="results") {
                foreach ($code as $kode){
                    if ($i >= $count) {
                        die("Done!");
                    } else {
                        $status = $kode['delivery']['status'];
                        $awb = $kode['id'];
                        $desc = $kode['description'];
                        $origin = $kode['origin']['value'];
                        $destination = $kode['destination']['value'];
                        //$str = "$key : $status : $awb";
    
                        echo "\033[32m$i. $key: $status : $awb : $destination : $desc \033[0m\n";
                        
                        file_put_contents('resi.txt',"$key : $status : $awb : $origin - $destination : $desc".PHP_EOL,FILE_APPEND);
                        $i++;

                    }
                }
            } else {
                echo "\033[31m$j. $key : INVALID AWB\033[0m\n";
                $j++;

            }
        }

        
    }

} else {
    echo "\033[31m KETIK JUMLAHNYA GOBLOK \033[0m\n";
}



function dhl($awb,$cookies){
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, 'https://www.dhl.com/shipmentTracking?AWB='.$awb.'&countryCode=g0&languageCode=en&_=1617645656661');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
    $headers = array();
    $headers[] = 'Authority: www.dhl.com';
    $headers[] = 'Sec-Ch-Ua: \"Google Chrome\";v=\"89\", \"Chromium\";v=\"89\", \";Not A Brand\";v=\"99\"';
    $headers[] = 'Accept: application/json, text/javascript, */*; q=0.01';
    $headers[] = 'X-Requested-With: XMLHttpRequest';
    $headers[] = 'Sec-Ch-Ua-Mobile: ?0';
    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36';
    $headers[] = 'Sec-Fetch-Site: same-origin';
    $headers[] = 'Sec-Fetch-Mode: cors';
    $headers[] = 'Sec-Fetch-Dest: empty';
    $headers[] = 'Referer: https://www.dhl.com/en/express/tracking.html?AWB=3874133863&brand=DHL';
    $headers[] = 'Accept-Language: id,en-US;q=0.9,en;q=0.8,und;q=0.7';
  //GANTI COOKIES LO MANUAL DISINI
    $headers[] = 'Cookie: ak_bmsc=E4C5F913744F6E3D524EECDB2C09862372050796521A000007F76C60F16D5523~plxZ8tBYMo/r7Bsei8cyey03u8UbuWAQRhxW9EppBJDW90ZeSNnjtatk0QnW3c7TE8SVvOcovS+e5izbqianPGuTxDsEBVBTyiT+deBOD7NKWh5tqjW2PnRxHkrk/uU40dgWgT9MbEaghjgIj3D9hAe6Z8v5Gnk7Kfmx0sycuO1UeOX9kPxZHOKcIm7avfXKNSHi0g6ZF3ysFAE3ziS6Q5/q6A8tCYRfs54I9W6eY7RF9nqXjo8kRq6UCdGt5Hnu83; bm_sz=61ABBDFB9809B81A4B7787105FD308C0~YAAQlgcFcrkkQqB4AQAAgfakqQvKs1TAERJp4MCWfsxS6J06SgaHMLB7KfPx2RHEykyXDXrv+7nVzofvsOe1ZDY9Lf26jYSUMS7vIEkJbs3sTKLmWYkUQeUfXjrE9+4MHSrhS7BkUnTD…JJqDOajaXRf4fFFMsc3NMl9Ph2/KbwQ8So4/ruAw5FHrVFu~-1~-1~-1; TS016f3c0b=01914b743d3171ec260a76c879aa5d545ce5e596e84d7ffe4be0360d6978813b4e0948390ff48fd1e46064ec150617c09fc379c258; dhl_cookie_consent=shown; RT="z=1&dm=www.dhl.com&si=d3890088-03f9-4e30-b771-bfa2794d4cd1&ss=kn73w8e6&sl=1&tt=1hw&rl=1&ld=2sg&ul=21uk&hd=225d"; bm_sv=22C12027AEAD070BA16D34242655E809~kdb5rE6eEQhwq/pzT3HIn92enPzfSi0IxGW5sO4bqUSEo17tI6u0U/zENwHl26BM/VHih2ymbzlwD5TWwmJNHx4IkqnOjxnuqU6fZ8G5loPoHEw2JDtTlzmc53M3gNIP0eA0dU4oPI+sHkV/jtAYAg=="; dhl_cookie_consent=accepted'; 
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    

    
    $result = curl_exec($ch);
    if (curl_errno($ch)) { 
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
    
    return $result;
}


?>
