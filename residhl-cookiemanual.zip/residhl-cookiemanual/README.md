# resi
DHL Auto Resi

Ganti Cookies Dulu, cookies ke refresh beberapa jam

How To USE
1. git clone https://github.com/m34l/resi.git
2. cd resi
3. php resi.php

